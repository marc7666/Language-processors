
// Segona capcalera

#include "capcalera.h"

int global = 3;

