

int funcio( int a );

